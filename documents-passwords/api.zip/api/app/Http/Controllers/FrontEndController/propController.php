<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class propController extends Controller
{
    //
}
